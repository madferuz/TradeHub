import Foundation
import Combine

@MainActor
final class CommunityViewModel: ObservableObject {
    @Published var ideas: [TradeIdea]
    let currentUser: AppUser

    private let service: CommunityServiceProtocol

    init(service: CommunityServiceProtocol = MockCommunityService.shared) {
        self.service = service
        self.ideas = service.feed()
        self.currentUser = service.currentUser()
    }

    func toggleLike(_ idea: TradeIdea) {
        guard let idx = ideas.firstIndex(where: { $0.id == idea.id }) else { return }
        ideas[idx].isLikedByMe.toggle()
        ideas[idx].likeCount += ideas[idx].isLikedByMe ? 1 : -1
    }

    func comments(for idea: TradeIdea) -> [IdeaComment] {
        service.comments(for: idea)
    }

    func publishIdea(symbol: String, direction: IdeaDirection, title: String, body: String) {
        let idea = TradeIdea(id: UUID(), author: currentUser, symbol: symbol, direction: direction, title: title, body: body, createdAt: Date(), likeCount: 0, commentCount: 0, isLikedByMe: false)
        ideas.insert(idea, at: 0)
    }

    func addComment(to idea: TradeIdea, text: String) {
        guard let idx = ideas.firstIndex(where: { $0.id == idea.id }) else { return }
        ideas[idx].commentCount += 1
    }
}
