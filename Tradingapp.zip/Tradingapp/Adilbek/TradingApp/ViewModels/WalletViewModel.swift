import Foundation
import Combine

@MainActor
final class WalletViewModel: ObservableObject {
    @Published var accounts: [BrokerAccount]
    @Published var transactions: [WalletTransaction]

    private let wallet: WalletServiceProtocol
    private let broker: BrokerServiceProtocol

    init(wallet: WalletServiceProtocol = MockWalletService.shared,
         broker: BrokerServiceProtocol = MockBrokerService.shared) {
        self.wallet = wallet
        self.broker = broker
        self.accounts = broker.connectedAccounts()
        self.transactions = wallet.transactions()
    }

    var totalBalance: Double {
        accounts.reduce(0) { $0 + $1.balance }
    }

    func deposit(amount: Double, method: PaymentMethod, into account: BrokerAccount) {
        let label = "\(account.brokerName) · \(account.accountNumber)"
        let tx = wallet.deposit(amount: amount, method: method, accountLabel: label)
        transactions.insert(tx, at: 0)
        if let idx = accounts.firstIndex(where: { $0.id == account.id }) {
            accounts[idx].balance += amount
            accounts[idx].equity += amount
        }
    }

    func withdraw(amount: Double, method: PaymentMethod, from account: BrokerAccount) {
        let label = "\(account.brokerName) · \(account.accountNumber)"
        let tx = wallet.withdraw(amount: amount, method: method, accountLabel: label)
        transactions.insert(tx, at: 0)
        if let idx = accounts.firstIndex(where: { $0.id == account.id }) {
            accounts[idx].balance = max(0, accounts[idx].balance - amount)
            accounts[idx].equity = max(0, accounts[idx].equity - amount)
        }
    }
}
