import Foundation
import Combine

@MainActor
final class PortfolioViewModel: ObservableObject {
    @Published var trades: [Trade]
    @Published var selectedFilter: OrderSide? = nil

    init(trading: TradingServiceProtocol = MockTradingService.shared) {
        self.trades = trading.tradeHistory()
    }

    var filteredTrades: [Trade] {
        guard let filter = selectedFilter else { return trades }
        return trades.filter { $0.side == filter }
    }

    var totalProfit: Double {
        trades.reduce(0) { $0 + $1.profit }
    }

    var winRate: Double {
        guard !trades.isEmpty else { return 0 }
        let wins = trades.filter { $0.profit > 0 }.count
        return Double(wins) / Double(trades.count)
    }

    /// Aggregate net P&L per calendar day, for the P&L calendar view.
    func dailyPnL(calendar: Calendar = .current) -> [Date: Double] {
        var result: [Date: Double] = [:]
        for trade in trades {
            let day = calendar.startOfDay(for: trade.closedAt)
            result[day, default: 0] += trade.profit
        }
        return result
    }
}
