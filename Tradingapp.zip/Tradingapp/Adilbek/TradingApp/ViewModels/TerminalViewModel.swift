import Foundation
import Combine

@MainActor
final class TerminalViewModel: ObservableObject {
    @Published var instruments: [Instrument]
    @Published var selectedInstrument: Instrument
    @Published var timeframe: Timeframe = .h1
    @Published var candles: [Candle] = []
    @Published var orderBook: OrderBookSnapshot
    @Published var activeIndicators: Set<IndicatorType> = [.sma20, .volume]
    @Published var livePrice: Double
    @Published var positions: [Position]
    @Published var showOrderTicket = false
    @Published var pendingSide: OrderSide = .buy

    private let marketData: MarketDataServiceProtocol
    private let trading: TradingServiceProtocol
    private var tickerCancellable: AnyCancellable?

    init(marketData: MarketDataServiceProtocol = MockMarketDataService.shared,
         trading: TradingServiceProtocol = MockTradingService.shared) {
        self.marketData = marketData
        self.trading = trading
        let all = marketData.instruments()
        self.instruments = all
        self.selectedInstrument = all.first!
        self.livePrice = all.first!.lastPrice
        self.orderBook = marketData.orderBook(for: all.first!.symbol)
        self.positions = trading.openPositions()
        loadCandles()
        subscribeTicker()
    }

    func select(_ instrument: Instrument) {
        selectedInstrument = instrument
        livePrice = instrument.lastPrice
        loadCandles()
        orderBook = marketData.orderBook(for: instrument.symbol)
        subscribeTicker()
    }

    func setTimeframe(_ tf: Timeframe) {
        timeframe = tf
        loadCandles()
    }

    func toggleIndicator(_ indicator: IndicatorType) {
        if activeIndicators.contains(indicator) {
            activeIndicators.remove(indicator)
        } else {
            activeIndicators.insert(indicator)
        }
    }

    func openOrderTicket(side: OrderSide) {
        pendingSide = side
        showOrderTicket = true
    }

    func confirmOrder(volume: Double, type: OrderType) {
        let newPosition = trading.placeOrder(symbol: selectedInstrument.symbol, side: pendingSide, type: type, volume: volume, price: livePrice)
        positions.insert(newPosition, at: 0)
        showOrderTicket = false
    }

    private func loadCandles() {
        candles = marketData.candles(for: selectedInstrument.symbol, timeframe: timeframe)
    }

    private func subscribeTicker() {
        tickerCancellable = marketData.priceTicker(for: selectedInstrument.symbol, basePrice: selectedInstrument.lastPrice)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] price in
                self?.livePrice = price
                self?.updatePositionPrices(price: price)
            }
    }

    private func updatePositionPrices(price: Double) {
        for i in positions.indices where positions[i].symbol == selectedInstrument.symbol {
            positions[i].currentPrice = price
        }
    }
}
