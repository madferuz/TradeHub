import Foundation
import Combine

@MainActor
final class BrokersViewModel: ObservableObject {
    @Published var availableBrokers: [Broker]
    @Published var connectedAccounts: [BrokerAccount]
    @Published var isConnecting = false

    private let service: BrokerServiceProtocol

    init(service: BrokerServiceProtocol = MockBrokerService.shared) {
        self.service = service
        self.availableBrokers = service.availableBrokers()
        self.connectedAccounts = service.connectedAccounts()
    }

    func connect(broker: Broker, login: String, password: String, server: String, completion: @escaping () -> Void) {
        isConnecting = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.1) { [weak self] in
            guard let self else { return }
            let account = self.service.connect(broker: broker, login: login, password: password, server: server)
            self.connectedAccounts.insert(account, at: 0)
            self.isConnecting = false
            completion()
        }
    }

    func disconnect(_ account: BrokerAccount) {
        service.disconnect(account: account)
        connectedAccounts.removeAll { $0.id == account.id }
    }
}
