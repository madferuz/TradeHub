import Foundation
import Combine

@MainActor
final class MessagingViewModel: ObservableObject {
    @Published var conversations: [Conversation]

    init(service: MessagingServiceProtocol = MockMessagingService.shared) {
        self.conversations = service.conversations()
    }

    func send(text: String, in conversation: Conversation) {
        guard let idx = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        let message = ChatMessage(id: UUID(), senderId: UUID(), text: text, sentAt: Date(), isMe: true)
        conversations[idx].messages.append(message)
        conversations[idx].lastMessagePreview = text
        conversations[idx].lastMessageDate = message.sentAt

        // Simulated reply for demo purposes.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { [weak self] in
            guard let self, let i = self.conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
            let reply = ChatMessage(id: UUID(), senderId: conversation.participant.id, text: "Got it — thanks for the update.", sentAt: Date(), isMe: false)
            self.conversations[i].messages.append(reply)
            self.conversations[i].lastMessagePreview = reply.text
            self.conversations[i].lastMessageDate = reply.sentAt
        }
    }
}
