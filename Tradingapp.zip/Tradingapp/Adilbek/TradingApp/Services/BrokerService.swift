import Foundation
import Combine

protocol BrokerServiceProtocol {
    func availableBrokers() -> [Broker]
    func connectedAccounts() -> [BrokerAccount]
    func connect(broker: Broker, login: String, password: String, server: String) -> BrokerAccount
    func disconnect(account: BrokerAccount)
}

/// Mock implementation simulating broker connection handshakes.
/// A real implementation would call each broker's trading API / FIX gateway here.
final class MockBrokerService: BrokerServiceProtocol {
    static let shared = MockBrokerService()

    func availableBrokers() -> [Broker] {
        MockDataGenerator.brokers
    }

    func connectedAccounts() -> [BrokerAccount] {
        MockDataGenerator.brokerAccounts()
    }

    func connect(broker: Broker, login: String, password: String, server: String) -> BrokerAccount {
        BrokerAccount(id: UUID(), brokerId: broker.id, brokerName: broker.name, accountNumber: login, balance: 10000, equity: 10000, currency: "USD", isConnected: true)
    }

    func disconnect(account: BrokerAccount) {
        // No-op for mock data.
    }
}
