import Foundation
import Combine

protocol TradingServiceProtocol {
    func openPositions() -> [Position]
    func tradeHistory() -> [Trade]
    func placeOrder(symbol: String, side: OrderSide, type: OrderType, volume: Double, price: Double) -> Position
}

/// Mock implementation. Replace with a real execution/broker service to place live orders.
final class MockTradingService: TradingServiceProtocol {
    static let shared = MockTradingService()

    func openPositions() -> [Position] {
        MockDataGenerator.positions()
    }

    func tradeHistory() -> [Trade] {
        MockDataGenerator.tradeHistory()
    }

    func placeOrder(symbol: String, side: OrderSide, type: OrderType, volume: Double, price: Double) -> Position {
        Position(id: UUID(), symbol: symbol, side: side, volume: volume, entryPrice: price, currentPrice: price, openedAt: Date())
    }
}
