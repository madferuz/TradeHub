import Foundation
import Combine

protocol MessagingServiceProtocol {
    func conversations() -> [Conversation]
}

final class MockMessagingService: MessagingServiceProtocol {
    static let shared = MockMessagingService()

    func conversations() -> [Conversation] {
        MockDataGenerator.conversations(users: MockDataGenerator.users())
    }
}
