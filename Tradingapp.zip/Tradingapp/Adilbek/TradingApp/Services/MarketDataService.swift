import Foundation
import Combine

protocol MarketDataServiceProtocol {
    func instruments() -> [Instrument]
    func candles(for symbol: String, timeframe: Timeframe) -> [Candle]
    func orderBook(for symbol: String) -> OrderBookSnapshot
    /// Emits a slowly ticking price update for the given symbol, simulating a live feed.
    func priceTicker(for symbol: String, basePrice: Double) -> AnyPublisher<Double, Never>
}

/// Mock implementation. Swap this out for a real broker/market-data SDK by
/// conforming a new type to `MarketDataServiceProtocol`.
final class MockMarketDataService: MarketDataServiceProtocol {
    static let shared = MockMarketDataService()

    func instruments() -> [Instrument] {
        MockDataGenerator.symbols
    }

    func candles(for symbol: String, timeframe: Timeframe) -> [Candle] {
        let base = MockDataGenerator.symbols.first(where: { $0.symbol == symbol })?.lastPrice ?? 100
        let volatility = symbol.contains("BTC") || symbol.contains("ETH") ? 0.006 : 0.0018
        return MockDataGenerator.candles(count: 140, startPrice: base, volatility: volatility, timeframe: timeframe)
    }

    func orderBook(for symbol: String) -> OrderBookSnapshot {
        let base = MockDataGenerator.symbols.first(where: { $0.symbol == symbol })?.lastPrice ?? 100
        return MockDataGenerator.orderBook(midPrice: base)
    }

    func priceTicker(for symbol: String, basePrice: Double) -> AnyPublisher<Double, Never> {
        Timer.publish(every: 1.4, on: .main, in: .common)
            .autoconnect()
            .scan(basePrice) { last, _ in
                let move = Double.random(in: -0.0009...0.0009)
                return max(0.0001, last + last * move)
            }
            .eraseToAnyPublisher()
    }
}
