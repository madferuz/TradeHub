import Foundation
import Combine

protocol WalletServiceProtocol {
    func transactions() -> [WalletTransaction]
    func deposit(amount: Double, method: PaymentMethod, accountLabel: String) -> WalletTransaction
    func withdraw(amount: Double, method: PaymentMethod, accountLabel: String) -> WalletTransaction
}

/// Mock implementation. Real deposits/withdrawals require a licensed payment
/// processor / banking partner integration, which is out of scope here.
final class MockWalletService: WalletServiceProtocol {
    static let shared = MockWalletService()

    func transactions() -> [WalletTransaction] {
        MockDataGenerator.transactions()
    }

    func deposit(amount: Double, method: PaymentMethod, accountLabel: String) -> WalletTransaction {
        WalletTransaction(id: UUID(), type: .deposit, amount: amount, currency: "USD", method: method, status: .pending, date: Date(), brokerAccountLabel: accountLabel)
    }

    func withdraw(amount: Double, method: PaymentMethod, accountLabel: String) -> WalletTransaction {
        WalletTransaction(id: UUID(), type: .withdrawal, amount: amount, currency: "USD", method: method, status: .pending, date: Date(), brokerAccountLabel: accountLabel)
    }
}
