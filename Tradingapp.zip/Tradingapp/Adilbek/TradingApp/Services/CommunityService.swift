import Foundation
import Combine

protocol CommunityServiceProtocol {
    func feed() -> [TradeIdea]
    func comments(for idea: TradeIdea) -> [IdeaComment]
    func currentUser() -> AppUser
    func allUsers() -> [AppUser]
}

final class MockCommunityService: CommunityServiceProtocol {
    static let shared = MockCommunityService()
    private let users = MockDataGenerator.users()

    func feed() -> [TradeIdea] {
        MockDataGenerator.tradeIdeas(users: users)
    }

    func comments(for idea: TradeIdea) -> [IdeaComment] {
        MockDataGenerator.comments(for: idea.id, users: users)
    }

    func currentUser() -> AppUser {
        users[0]
    }

    func allUsers() -> [AppUser] {
        users
    }
}
