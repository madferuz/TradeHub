import SwiftUI

enum Theme {
    static let bg = Color(.systemBackground)
    static let cardBg = Color(.secondarySystemBackground)
    static let bullish = Color(red: 0.13, green: 0.76, blue: 0.47)
    static let bearish = Color(red: 0.92, green: 0.27, blue: 0.33)
    static let accent = Color(red: 0.20, green: 0.47, blue: 0.98)
    static let subtleText = Color.secondary

    static func pnlColor(_ value: Double) -> Color {
        value >= 0 ? bullish : bearish
    }
}

struct CardBackground: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding()
            .background(Theme.cardBg)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

extension View {
    func cardStyle() -> some View { modifier(CardBackground()) }
}
