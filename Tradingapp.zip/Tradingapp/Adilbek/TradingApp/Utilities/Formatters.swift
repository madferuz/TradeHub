import Foundation

enum Formatters {
    static func currency(_ value: Double, symbol: String = "$") -> String {
        let sign = value < 0 ? "-" : ""
        let formatted = String(format: "%.2f", abs(value))
        return "\(sign)\(symbol)\(insertThousands(formatted))"
    }

    static func signedCurrency(_ value: Double, symbol: String = "$") -> String {
        let sign = value >= 0 ? "+" : "-"
        let formatted = String(format: "%.2f", abs(value))
        return "\(sign)\(symbol)\(insertThousands(formatted))"
    }

    static func price(_ value: Double, decimals: Int = 2) -> String {
        String(format: "%.\(decimals)f", value)
    }

    static func percent(_ value: Double) -> String {
        let sign = value >= 0 ? "+" : ""
        return "\(sign)\(String(format: "%.2f", value))%"
    }

    static func relativeDate(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }

    static func shortDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d"
        return formatter.string(from: date)
    }

    static func time(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }

    private static func insertThousands(_ numberString: String) -> String {
        let parts = numberString.split(separator: ".")
        guard let intPart = parts.first else { return numberString }
        var chars = Array(String(intPart))
        var result = ""
        var count = 0
        for c in chars.reversed() {
            result.append(c)
            count += 1
            if count % 3 == 0 && count != chars.count { result.append(",") }
        }
        let intResult = String(result.reversed())
        if parts.count > 1 {
            return "\(intResult).\(parts[1])"
        }
        return intResult
    }
}
