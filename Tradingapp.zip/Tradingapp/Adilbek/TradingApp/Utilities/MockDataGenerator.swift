import Foundation

enum MockDataGenerator {

    static let symbols: [Instrument] = [
        Instrument(symbol: "EURUSD", name: "Euro / US Dollar", assetClass: .forex, lastPrice: 1.0873, change: 0.0021, changePercent: 0.19),
        Instrument(symbol: "GBPUSD", name: "British Pound / US Dollar", assetClass: .forex, lastPrice: 1.2694, change: -0.0043, changePercent: -0.34),
        Instrument(symbol: "BTCUSD", name: "Bitcoin", assetClass: .crypto, lastPrice: 63250.40, change: 812.30, changePercent: 1.30),
        Instrument(symbol: "ETHUSD", name: "Ethereum", assetClass: .crypto, lastPrice: 3120.15, change: -45.20, changePercent: -1.43),
        Instrument(symbol: "AAPL", name: "Apple Inc.", assetClass: .stock, lastPrice: 221.35, change: 1.85, changePercent: 0.84),
        Instrument(symbol: "TSLA", name: "Tesla Inc.", assetClass: .stock, lastPrice: 248.60, change: -3.10, changePercent: -1.23),
        Instrument(symbol: "US30", name: "Dow Jones 30", assetClass: .index, lastPrice: 39875.0, change: 120.0, changePercent: 0.30),
        Instrument(symbol: "XAUUSD", name: "Gold", assetClass: .commodity, lastPrice: 2385.60, change: 6.40, changePercent: 0.27)
    ]

    static let brokers: [Broker] = [
        Broker(id: "alpha", name: "AlphaTrade Global", logoSystemName: "chart.line.uptrend.xyaxis", supportsForex: true, supportsCrypto: true, supportsStocks: true),
        Broker(id: "nova", name: "Nova Markets", logoSystemName: "sparkles", supportsForex: true, supportsCrypto: false, supportsStocks: true),
        Broker(id: "pinnacle", name: "Pinnacle FX", logoSystemName: "triangle", supportsForex: true, supportsCrypto: false, supportsStocks: false),
        Broker(id: "quantum", name: "Quantum Capital", logoSystemName: "atom", supportsForex: true, supportsCrypto: true, supportsStocks: true)
    ]

    static func candles(count: Int = 120, startPrice: Double = 1.0873, volatility: Double = 0.0018, timeframe: Timeframe = .h1) -> [Candle] {
        var result: [Candle] = []
        var price = startPrice
        let interval: TimeInterval
        switch timeframe {
        case .m1: interval = 60
        case .m5: interval = 300
        case .m15: interval = 900
        case .h1: interval = 3600
        case .h4: interval = 14400
        case .d1: interval = 86400
        }
        let now = Date()
        for i in 0..<count {
            let date = now.addingTimeInterval(-Double(count - i) * interval)
            let open = price
            let driftBias = sin(Double(i) / 9.0) * volatility * 0.6
            let randomMove = Double.random(in: -volatility...volatility) + driftBias
            let close = max(0.0001, open + open * randomMove)
            let high = max(open, close) + open * Double.random(in: 0...volatility * 0.6)
            let low = min(open, close) - open * Double.random(in: 0...volatility * 0.6)
            let volume = Double.random(in: 800...5200)
            result.append(Candle(date: date, open: open, high: high, low: low, close: close, volume: volume))
            price = close
        }
        return result
    }

    static func orderBook(midPrice: Double) -> OrderBookSnapshot {
        var bids: [OrderBookLevel] = []
        var asks: [OrderBookLevel] = []
        let tick = midPrice * 0.00006
        for i in 1...10 {
            bids.append(OrderBookLevel(price: midPrice - tick * Double(i), size: Double.random(in: 0.2...9.0)))
            asks.append(OrderBookLevel(price: midPrice + tick * Double(i), size: Double.random(in: 0.2...9.0)))
        }
        return OrderBookSnapshot(bids: bids, asks: asks)
    }

    static func positions() -> [Position] {
        [
            Position(id: UUID(), symbol: "EURUSD", side: .buy, volume: 1.5, entryPrice: 1.0821, currentPrice: 1.0873, openedAt: Date().addingTimeInterval(-3600 * 5)),
            Position(id: UUID(), symbol: "BTCUSD", side: .sell, volume: 0.4, entryPrice: 64100, currentPrice: 63250.4, openedAt: Date().addingTimeInterval(-3600 * 14)),
            Position(id: UUID(), symbol: "TSLA", side: .buy, volume: 25, entryPrice: 252.10, currentPrice: 248.60, openedAt: Date().addingTimeInterval(-3600 * 30))
        ]
    }

    static func tradeHistory(days: Int = 60) -> [Trade] {
        var trades: [Trade] = []
        let symbolsPool = symbols.map { $0.symbol }
        let brokerNames = brokers.map { $0.name }
        let now = Date()
        for _ in 0..<days {
            let dayOffset = Double.random(in: 0...Double(days))
            let openDate = now.addingTimeInterval(-dayOffset * 86400 - Double.random(in: 0...20000))
            let closeDate = openDate.addingTimeInterval(Double.random(in: 600...18000))
            let symbol = symbolsPool.randomElement()!
            let side: OrderSide = Bool.random() ? .buy : .sell
            let entry = Double.random(in: 50...65000)
            let profitDirection: Double = Double.random(in: -1...1)
            let profit = profitDirection * Double.random(in: 5...480)
            let exit = entry + (side == .buy ? profit : -profit) / 100
            trades.append(Trade(id: UUID(), symbol: symbol, side: side, volume: Double.random(in: 0.1...5), entryPrice: entry, exitPrice: exit, openedAt: openDate, closedAt: closeDate, profit: profit, brokerName: brokerNames.randomElement()!))
        }
        return trades.sorted { $0.closedAt > $1.closedAt }
    }

    static func brokerAccounts() -> [BrokerAccount] {
        [
            BrokerAccount(id: UUID(), brokerId: "alpha", brokerName: "AlphaTrade Global", accountNumber: "AC-88213", balance: 12480.55, equity: 12611.20, currency: "USD", isConnected: true),
            BrokerAccount(id: UUID(), brokerId: "nova", brokerName: "Nova Markets", accountNumber: "NM-40217", balance: 3200.00, equity: 3185.40, currency: "USD", isConnected: true)
        ]
    }

    static func transactions() -> [WalletTransaction] {
        let now = Date()
        return [
            WalletTransaction(id: UUID(), type: .deposit, amount: 2000, currency: "USD", method: .bankTransfer, status: .completed, date: now.addingTimeInterval(-86400 * 2), brokerAccountLabel: "AlphaTrade Global · AC-88213"),
            WalletTransaction(id: UUID(), type: .withdrawal, amount: 500, currency: "USD", method: .card, status: .completed, date: now.addingTimeInterval(-86400 * 6), brokerAccountLabel: "AlphaTrade Global · AC-88213"),
            WalletTransaction(id: UUID(), type: .deposit, amount: 1000, currency: "USD", method: .crypto, status: .pending, date: now.addingTimeInterval(-86400 * 1), brokerAccountLabel: "Nova Markets · NM-40217"),
            WalletTransaction(id: UUID(), type: .withdrawal, amount: 250, currency: "USD", method: .bankTransfer, status: .failed, date: now.addingTimeInterval(-86400 * 10), brokerAccountLabel: "Nova Markets · NM-40217")
        ]
    }

    static func users() -> [AppUser] {
        [
            AppUser(id: UUID(), username: "you", displayName: "You", avatarSystemName: "person.circle.fill", bio: "Trend follower. Risk 1% per trade.", followers: 128, following: 64, winRate: 0.58),
            AppUser(id: UUID(), username: "maria_fx", displayName: "Maria Chen", avatarSystemName: "person.crop.circle.fill", bio: "Swing trading majors & gold.", followers: 4200, following: 180, winRate: 0.63),
            AppUser(id: UUID(), username: "devon_charts", displayName: "Devon Blake", avatarSystemName: "person.crop.circle.badge.checkmark", bio: "Crypto scalper. NY session.", followers: 2100, following: 90, winRate: 0.51),
            AppUser(id: UUID(), username: "aki_trades", displayName: "Aki Tanaka", avatarSystemName: "person.crop.circle", bio: "Index futures, macro driven.", followers: 980, following: 210, winRate: 0.55)
        ]
    }

    static func tradeIdeas(users: [AppUser]) -> [TradeIdea] {
        let now = Date()
        guard users.count >= 4 else { return [] }
        return [
            TradeIdea(id: UUID(), author: users[1], symbol: "XAUUSD", direction: .long, title: "Gold reclaiming 2,380 support", body: "Price swept liquidity below the range low and reclaimed structure on the 4H. Looking for continuation toward 2,410 while price holds above 2,378.", createdAt: now.addingTimeInterval(-3600 * 3), likeCount: 214, commentCount: 18, isLikedByMe: false),
            TradeIdea(id: UUID(), author: users[2], symbol: "BTCUSD", direction: .short, title: "BTC rejecting 64k supply zone", body: "Clear rejection wick on the 1H at the prior distribution zone. Watching for a break of 62,800 to confirm the short toward 61,200.", createdAt: now.addingTimeInterval(-3600 * 7), likeCount: 156, commentCount: 24, isLikedByMe: true),
            TradeIdea(id: UUID(), author: users[3], symbol: "US30", direction: .long, title: "Dow holding trendline since March", body: "The ascending trendline from the March low is still intact. As long as we hold above 39,600 this stays a buy-the-dip market into NFP.", createdAt: now.addingTimeInterval(-3600 * 20), likeCount: 89, commentCount: 11, isLikedByMe: false),
            TradeIdea(id: UUID(), author: users[1], symbol: "EURUSD", direction: .short, title: "EUR losing momentum into ECB", body: "Momentum divergence on the daily RSI with price stalling below 1.0900. A fade into the ECB decision looks attractive with tight risk above 1.0910.", createdAt: now.addingTimeInterval(-3600 * 30), likeCount: 302, commentCount: 41, isLikedByMe: false)
        ]
    }

    static func comments(for ideaId: UUID, users: [AppUser]) -> [IdeaComment] {
        let now = Date()
        guard users.count >= 4 else { return [] }
        return [
            IdeaComment(id: UUID(), ideaId: ideaId, author: users[3], text: "Great read on the structure, watching the same level.", createdAt: now.addingTimeInterval(-3200)),
            IdeaComment(id: UUID(), ideaId: ideaId, author: users[0], text: "What's your invalidation on this one?", createdAt: now.addingTimeInterval(-2600)),
            IdeaComment(id: UUID(), ideaId: ideaId, author: users[2], text: "Took a small position, thanks for sharing.", createdAt: now.addingTimeInterval(-900))
        ]
    }

    static func conversations(users: [AppUser]) -> [Conversation] {
        let now = Date()
        guard users.count >= 4 else { return [] }
        let convo1Messages = [
            ChatMessage(id: UUID(), senderId: users[1].id, text: "Hey, did you see the gold setup I posted?", sentAt: now.addingTimeInterval(-5000), isMe: false),
            ChatMessage(id: UUID(), senderId: users[0].id, text: "Yeah, looks clean. Are you sizing full risk on it?", sentAt: now.addingTimeInterval(-4800), isMe: true),
            ChatMessage(id: UUID(), senderId: users[1].id, text: "Half size until it clears 2,390.", sentAt: now.addingTimeInterval(-4600), isMe: false)
        ]
        let convo2Messages = [
            ChatMessage(id: UUID(), senderId: users[2].id, text: "That BTC short is playing out nicely.", sentAt: now.addingTimeInterval(-9000), isMe: false),
            ChatMessage(id: UUID(), senderId: users[0].id, text: "Nice, are you trailing the stop?", sentAt: now.addingTimeInterval(-8800), isMe: true)
        ]
        return [
            Conversation(id: UUID(), participant: users[1], messages: convo1Messages, lastMessagePreview: convo1Messages.last!.text, lastMessageDate: convo1Messages.last!.sentAt, unreadCount: 0),
            Conversation(id: UUID(), participant: users[2], messages: convo2Messages, lastMessagePreview: convo2Messages.last!.text, lastMessageDate: convo2Messages.last!.sentAt, unreadCount: 2),
            Conversation(id: UUID(), participant: users[3], messages: [], lastMessagePreview: "Started following you", lastMessageDate: now.addingTimeInterval(-90000), unreadCount: 0)
        ]
    }
}
