import SwiftUI

@main
struct TradingAppApp: App {
    var body: some Scene {
        WindowGroup {
            RootTabView()
        }
    }
}
