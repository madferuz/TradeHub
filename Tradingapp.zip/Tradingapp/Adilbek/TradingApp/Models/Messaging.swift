import Foundation

struct ChatMessage: Identifiable, Codable {
    let id: UUID
    let senderId: UUID
    let text: String
    let sentAt: Date
    var isMe: Bool
}

struct Conversation: Identifiable, Codable {
    let id: UUID
    let participant: AppUser
    var messages: [ChatMessage]
    var lastMessagePreview: String
    var lastMessageDate: Date
    var unreadCount: Int
}
