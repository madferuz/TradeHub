import Foundation

enum TransactionType: String, Codable { case deposit = "Deposit", withdrawal = "Withdrawal" }
enum TransactionStatus: String, Codable { case completed = "Completed", pending = "Pending", failed = "Failed" }
enum PaymentMethod: String, Codable, CaseIterable, Identifiable {
    case bankTransfer = "Bank Transfer"
    case card = "Debit/Credit Card"
    case crypto = "Crypto Wallet"
    var id: String { rawValue }
    var systemImage: String {
        switch self {
        case .bankTransfer: return "building.columns"
        case .card: return "creditcard"
        case .crypto: return "bitcoinsign.circle"
        }
    }
}

struct WalletTransaction: Identifiable, Codable {
    let id: UUID
    let type: TransactionType
    let amount: Double
    let currency: String
    let method: PaymentMethod
    let status: TransactionStatus
    let date: Date
    let brokerAccountLabel: String
}
