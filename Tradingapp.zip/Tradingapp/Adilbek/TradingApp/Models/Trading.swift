import Foundation

enum OrderSide: String, Codable { case buy = "Buy", sell = "Sell" }
enum OrderType: String, Codable, CaseIterable { case market = "Market", limit = "Limit", stop = "Stop" }

struct Position: Identifiable, Codable {
    let id: UUID
    let symbol: String
    let side: OrderSide
    var volume: Double
    let entryPrice: Double
    var currentPrice: Double
    let openedAt: Date

    var pnl: Double {
        let direction = side == .buy ? 1.0 : -1.0
        return (currentPrice - entryPrice) * volume * direction
    }
}

struct Trade: Identifiable, Codable {
    let id: UUID
    let symbol: String
    let side: OrderSide
    let volume: Double
    let entryPrice: Double
    let exitPrice: Double
    let openedAt: Date
    let closedAt: Date
    let profit: Double
    let brokerName: String
}

struct Broker: Identifiable, Hashable, Codable {
    let id: String
    let name: String
    let logoSystemName: String
    let supportsForex: Bool
    let supportsCrypto: Bool
    let supportsStocks: Bool
}

struct BrokerAccount: Identifiable, Hashable, Codable {
    let id: UUID
    let brokerId: String
    let brokerName: String
    let accountNumber: String
    var balance: Double
    var equity: Double
    let currency: String
    var isConnected: Bool
}
