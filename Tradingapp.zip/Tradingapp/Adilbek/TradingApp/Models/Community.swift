import Foundation

enum IdeaDirection: String, Codable { case long = "Long", short = "Short" }

struct TradeIdea: Identifiable, Codable {
    let id: UUID
    let author: AppUser
    let symbol: String
    let direction: IdeaDirection
    let title: String
    let body: String
    let createdAt: Date
    var likeCount: Int
    var commentCount: Int
    var isLikedByMe: Bool
}

struct IdeaComment: Identifiable, Codable {
    let id: UUID
    let ideaId: UUID
    let author: AppUser
    let text: String
    let createdAt: Date
}
