import Foundation

struct AppUser: Identifiable, Codable {
    let id: UUID
    var username: String
    var displayName: String
    var avatarSystemName: String
    var bio: String
    var followers: Int
    var following: Int
    var winRate: Double
}
