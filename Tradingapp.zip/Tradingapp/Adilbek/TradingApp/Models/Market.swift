import Foundation

struct Instrument: Identifiable, Hashable, Codable {
    var id: String { symbol }
    let symbol: String
    let name: String
    let assetClass: AssetClass
    var lastPrice: Double
    var change: Double
    var changePercent: Double

    enum AssetClass: String, Codable, CaseIterable {
        case forex = "Forex"
        case crypto = "Crypto"
        case stock = "Stocks"
        case index = "Indices"
        case commodity = "Commodities"
    }
}

struct Candle: Identifiable, Codable {
    var id: Date { date }
    let date: Date
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    let volume: Double
}

enum Timeframe: String, CaseIterable, Identifiable {
    case m1 = "1m", m5 = "5m", m15 = "15m", h1 = "1H", h4 = "4H", d1 = "1D"
    var id: String { rawValue }
}

enum IndicatorType: String, CaseIterable, Identifiable {
    case sma20 = "SMA 20"
    case ema50 = "EMA 50"
    case volume = "Volume"
    var id: String { rawValue }
}

struct OrderBookLevel: Identifiable {
    let id = UUID()
    let price: Double
    let size: Double
}

struct OrderBookSnapshot {
    let bids: [OrderBookLevel]
    let asks: [OrderBookLevel]
}
