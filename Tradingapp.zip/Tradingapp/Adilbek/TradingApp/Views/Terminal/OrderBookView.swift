import SwiftUI

struct OrderBookView: View {
    let snapshot: OrderBookSnapshot
    let decimals: Int

    private var maxSize: Double {
        max(snapshot.bids.map { $0.size }.max() ?? 1, snapshot.asks.map { $0.size }.max() ?? 1)
    }

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Order Book").font(.headline)
                Spacer()
            }
            HStack(alignment: .top, spacing: 12) {
                VStack(spacing: 4) {
                    Text("Bids").font(.caption).foregroundStyle(.secondary)
                    ForEach(snapshot.bids) { level in
                        levelRow(level: level, color: Theme.bullish)
                    }
                }
                VStack(spacing: 4) {
                    Text("Asks").font(.caption).foregroundStyle(.secondary)
                    ForEach(snapshot.asks) { level in
                        levelRow(level: level, color: Theme.bearish)
                    }
                }
            }
        }
        .cardStyle()
    }

    private func levelRow(level: OrderBookLevel, color: Color) -> some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Rectangle()
                    .fill(color.opacity(0.14))
                    .frame(width: geo.size.width * CGFloat(level.size / maxSize))
                HStack {
                    Text(Formatters.price(level.price, decimals: decimals))
                        .font(.caption.monospaced())
                        .foregroundStyle(color)
                    Spacer()
                    Text(Formatters.price(level.size, decimals: 2))
                        .font(.caption2.monospaced())
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 4)
            }
        }
        .frame(height: 18)
    }
}
