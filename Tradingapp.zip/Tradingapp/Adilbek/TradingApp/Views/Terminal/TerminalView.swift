import SwiftUI

struct TerminalView: View {
    @StateObject private var viewModel = TerminalViewModel()
    @State private var showWatchlist = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    header
                    timeframeAndIndicators
                    chartCard
                    OrderBookView(snapshot: viewModel.orderBook, decimals: viewModel.selectedInstrument.assetClass == .forex ? 5 : 2)
                    tradeButtons
                    openPositionsSection
                }
                .padding()
            }
            .navigationTitle("Terminal")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showWatchlist = true
                    } label: {
                        Image(systemName: "list.bullet")
                    }
                }
            }
            .sheet(isPresented: $showWatchlist) {
                NavigationStack { WatchlistView(viewModel: viewModel) }
            }
            .sheet(isPresented: $viewModel.showOrderTicket) {
                OrderTicketView(viewModel: viewModel)
            }
        }
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: 4) {
                Text(viewModel.selectedInstrument.symbol).font(.title2.bold())
                Text(viewModel.selectedInstrument.name).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 4) {
                Text(Formatters.price(viewModel.livePrice, decimals: viewModel.selectedInstrument.assetClass == .forex ? 4 : 2))
                    .font(.title2.monospacedDigit().bold())
                Text(Formatters.percent(viewModel.selectedInstrument.changePercent))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Theme.pnlColor(viewModel.selectedInstrument.changePercent))
            }
        }
    }

    private var timeframeAndIndicators: some View {
        VStack(alignment: .leading, spacing: 8) {
            Picker("Timeframe", selection: Binding(get: { viewModel.timeframe }, set: { viewModel.setTimeframe($0) })) {
                ForEach(Timeframe.allCases) { tf in Text(tf.rawValue).tag(tf) }
            }
            .pickerStyle(.segmented)

            HStack(spacing: 8) {
                ForEach(IndicatorType.allCases) { indicator in
                    let isOn = viewModel.activeIndicators.contains(indicator)
                    Button {
                        viewModel.toggleIndicator(indicator)
                    } label: {
                        Text(indicator.rawValue)
                            .font(.caption2.weight(.medium))
                            .padding(.horizontal, 10).padding(.vertical, 5)
                            .background(isOn ? Theme.accent.opacity(0.18) : Theme.cardBg)
                            .foregroundStyle(isOn ? Theme.accent : .secondary)
                            .clipShape(Capsule())
                    }
                }
            }
        }
    }

    private var chartCard: some View {
        CandlestickChartView(candles: viewModel.candles, activeIndicators: viewModel.activeIndicators)
            .frame(height: 300)
            .cardStyle()
    }

    private var tradeButtons: some View {
        HStack(spacing: 12) {
            Button {
                viewModel.openOrderTicket(side: .sell)
            } label: {
                VStack {
                    Text("Sell").font(.headline)
                    Text(Formatters.price(viewModel.livePrice, decimals: 4)).font(.caption.monospaced())
                }
                .frame(maxWidth: .infinity).padding(.vertical, 12)
                .background(Theme.bearish.opacity(0.15))
                .foregroundStyle(Theme.bearish)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Button {
                viewModel.openOrderTicket(side: .buy)
            } label: {
                VStack {
                    Text("Buy").font(.headline)
                    Text(Formatters.price(viewModel.livePrice, decimals: 4)).font(.caption.monospaced())
                }
                .frame(maxWidth: .infinity).padding(.vertical, 12)
                .background(Theme.bullish.opacity(0.15))
                .foregroundStyle(Theme.bullish)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
    }

    private var openPositionsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(title: "Open Positions")
            if viewModel.positions.isEmpty {
                EmptyStateView(systemImage: "tray", title: "No open positions", message: "Trades you open will show up here.")
            } else {
                ForEach(viewModel.positions) { position in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            HStack(spacing: 6) {
                                Text(position.symbol).font(.subheadline.weight(.semibold))
                                Text(position.side.rawValue.uppercased())
                                    .font(.caption2.weight(.bold))
                                    .padding(.horizontal, 6).padding(.vertical, 2)
                                    .background(position.side == .buy ? Theme.bullish.opacity(0.15) : Theme.bearish.opacity(0.15))
                                    .foregroundStyle(position.side == .buy ? Theme.bullish : Theme.bearish)
                                    .clipShape(Capsule())
                            }
                            Text("\(Formatters.price(position.volume, decimals: 2)) lots @ \(Formatters.price(position.entryPrice, decimals: 4))")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                        PnLBadge(value: position.pnl)
                    }
                    .padding(.vertical, 6)
                    Divider()
                }
            }
        }
        .cardStyle()
    }
}

#Preview {
    TerminalView()
}
