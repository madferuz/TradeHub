import SwiftUI

struct WatchlistView: View {
    @ObservedObject var viewModel: TerminalViewModel

    var body: some View {
        List(viewModel.instruments) { instrument in
            Button {
                viewModel.select(instrument)
            } label: {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(instrument.symbol).font(.subheadline.weight(.semibold))
                        Text(instrument.assetClass.rawValue).font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(Formatters.price(instrument.lastPrice, decimals: instrument.assetClass == .forex ? 4 : 2))
                            .font(.subheadline.monospaced())
                        Text(Formatters.percent(instrument.changePercent))
                            .font(.caption2)
                            .foregroundStyle(Theme.pnlColor(instrument.changePercent))
                    }
                }
                .foregroundStyle(.primary)
                .padding(.vertical, 2)
            }
            .listRowBackground(instrument.id == viewModel.selectedInstrument.id ? Theme.accent.opacity(0.08) : Color.clear)
        }
        .listStyle(.plain)
        .navigationTitle("Watchlist")
    }
}
