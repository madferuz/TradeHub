import SwiftUI

/// A self-contained candlestick chart drawn with SwiftUI's Canvas API,
/// with optional SMA/EMA overlay lines and a volume histogram beneath it.
struct CandlestickChartView: View {
    let candles: [Candle]
    let activeIndicators: Set<IndicatorType>

    @State private var selectedIndex: Int? = nil

    private var showsVolume: Bool { activeIndicators.contains(.volume) }

    var body: some View {
        GeometryReader { geo in
            let priceHeight = showsVolume ? geo.size.height * 0.78 : geo.size.height
            let volumeHeight = geo.size.height - priceHeight

            let highs = candles.map { $0.high }
            let lows = candles.map { $0.low }
            let maxPrice = (highs.max() ?? 1) * 1.0006
            let minPrice = (lows.min() ?? 0) * 0.9994
            let priceRange = max(maxPrice - minPrice, 0.0001)
            let maxVolume = candles.map { $0.volume }.max() ?? 1
            let count = max(candles.count, 1)
            let slotWidth = geo.size.width / CGFloat(count)
            let bodyWidth = max(slotWidth * 0.55, 1.5)

            ZStack(alignment: .topLeading) {
                Canvas { context, size in
                    // Gridlines
                    for i in 0...4 {
                        let y = priceHeight * CGFloat(i) / 4
                        var path = Path()
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: size.width, y: y))
                        context.stroke(path, with: .color(.secondary.opacity(0.12)), lineWidth: 0.5)
                    }

                    // Candles
                    for (index, candle) in candles.enumerated() {
                        let x = CGFloat(index) * slotWidth + slotWidth / 2
                        let isBullish = candle.close >= candle.open
                        let color = isBullish ? Theme.bullish : Theme.bearish

                        func yFor(_ price: Double) -> CGFloat {
                            priceHeight * (1 - CGFloat((price - minPrice) / priceRange))
                        }

                        var wick = Path()
                        wick.move(to: CGPoint(x: x, y: yFor(candle.high)))
                        wick.addLine(to: CGPoint(x: x, y: yFor(candle.low)))
                        context.stroke(wick, with: .color(color), lineWidth: 1)

                        let openY = yFor(candle.open)
                        let closeY = yFor(candle.close)
                        let bodyRect = CGRect(x: x - bodyWidth / 2, y: min(openY, closeY), width: bodyWidth, height: max(abs(closeY - openY), 1))
                        context.fill(Path(roundedRect: bodyRect, cornerRadius: 1), with: .color(color))

                        if showsVolume {
                            let volY = size.height - volumeHeight * CGFloat(candle.volume / maxVolume)
                            let volRect = CGRect(x: x - bodyWidth / 2, y: max(volY, priceHeight + 2), width: bodyWidth, height: max(size.height - max(volY, priceHeight + 2), 1))
                            context.fill(Path(roundedRect: volRect, cornerRadius: 1), with: .color(color.opacity(0.5)))
                        }
                    }

                    // Indicator overlays
                    if activeIndicators.contains(.sma20) {
                        drawLine(context: &context, values: movingAverage(period: 20), minPrice: minPrice, priceRange: priceRange, priceHeight: priceHeight, slotWidth: slotWidth, color: .orange)
                    }
                    if activeIndicators.contains(.ema50) {
                        drawLine(context: &context, values: exponentialMovingAverage(period: 50), minPrice: minPrice, priceRange: priceRange, priceHeight: priceHeight, slotWidth: slotWidth, color: .purple)
                    }
                }
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            let idx = Int(value.location.x / slotWidth)
                            selectedIndex = min(max(idx, 0), candles.count - 1)
                        }
                        .onEnded { _ in selectedIndex = nil }
                )

                if let selectedIndex, candles.indices.contains(selectedIndex) {
                    let candle = candles[selectedIndex]
                    VStack(alignment: .leading, spacing: 2) {
                        Text("O \(Formatters.price(candle.open, decimals: 4))  H \(Formatters.price(candle.high, decimals: 4))")
                        Text("L \(Formatters.price(candle.low, decimals: 4))  C \(Formatters.price(candle.close, decimals: 4))")
                        Text(Formatters.time(candle.date)).foregroundStyle(.secondary)
                    }
                    .font(.caption2.monospaced())
                    .padding(6)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 8))
                    .padding(6)
                }
            }
        }
    }

    private func movingAverage(period: Int) -> [Double?] {
        var result: [Double?] = Array(repeating: nil, count: candles.count)
        guard candles.count >= period else { return result }
        var sum = 0.0
        for i in 0..<candles.count {
            sum += candles[i].close
            if i >= period { sum -= candles[i - period].close }
            if i >= period - 1 { result[i] = sum / Double(period) }
        }
        return result
    }

    private func exponentialMovingAverage(period: Int) -> [Double?] {
        var result: [Double?] = Array(repeating: nil, count: candles.count)
        guard !candles.isEmpty else { return result }
        let k = 2.0 / (Double(period) + 1.0)
        var emaPrev = candles[0].close
        for i in 0..<candles.count {
            let close = candles[i].close
            emaPrev = i == 0 ? close : (close * k + emaPrev * (1 - k))
            if i >= min(period, candles.count) - 1 { result[i] = emaPrev }
        }
        return result
    }

    private func drawLine(context: inout GraphicsContext, values: [Double?], minPrice: Double, priceRange: Double, priceHeight: CGFloat, slotWidth: CGFloat, color: Color) {
        var path = Path()
        var started = false
        for (index, value) in values.enumerated() {
            guard let value else { continue }
            let x = CGFloat(index) * slotWidth + slotWidth / 2
            let y = priceHeight * (1 - CGFloat((value - minPrice) / priceRange))
            if !started {
                path.move(to: CGPoint(x: x, y: y))
                started = true
            } else {
                path.addLine(to: CGPoint(x: x, y: y))
            }
        }
        context.stroke(path, with: .color(color), lineWidth: 1.4)
    }
}
