import SwiftUI

struct OrderTicketView: View {
    @ObservedObject var viewModel: TerminalViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var volumeText: String = "1.0"
    @State private var orderType: OrderType = .market

    var body: some View {
        NavigationStack {
            Form {
                Section("Instrument") {
                    HStack {
                        Text(viewModel.selectedInstrument.symbol).font(.headline)
                        Spacer()
                        Text(Formatters.price(viewModel.livePrice, decimals: 4)).font(.headline.monospaced())
                    }
                }
                Section("Side") {
                    Picker("Side", selection: $viewModel.pendingSide) {
                        Text("Buy").tag(OrderSide.buy)
                        Text("Sell").tag(OrderSide.sell)
                    }
                    .pickerStyle(.segmented)
                }
                Section("Order Type") {
                    Picker("Type", selection: $orderType) {
                        ForEach(OrderType.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                    .pickerStyle(.segmented)
                }
                Section("Volume (lots)") {
                    TextField("Volume", text: $volumeText)
                        .keyboardType(.decimalPad)
                }
                Section {
                    Text("Estimated cost: \(Formatters.currency((Double(volumeText) ?? 0) * viewModel.livePrice))")
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("New Order")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(viewModel.pendingSide == .buy ? "Buy" : "Sell") {
                        viewModel.confirmOrder(volume: Double(volumeText) ?? 1, type: orderType)
                        dismiss()
                    }
                    .tint(viewModel.pendingSide == .buy ? Theme.bullish : Theme.bearish)
                }
            }
        }
    }
}
