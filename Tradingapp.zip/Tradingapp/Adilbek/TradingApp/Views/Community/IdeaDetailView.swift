import SwiftUI

struct IdeaDetailView: View {
    let idea: TradeIdea
    @ObservedObject var viewModel: CommunityViewModel
    @State private var commentText = ""
    @State private var comments: [IdeaComment] = []

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                IdeaCardView(idea: idea, onLike: { viewModel.toggleLike(idea) })
                SectionHeader(title: "Comments")
                ForEach(comments) { comment in
                    HStack(alignment: .top, spacing: 10) {
                        AvatarView(systemName: comment.author.avatarSystemName, size: 28)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(comment.author.displayName).font(.caption.weight(.semibold))
                            Text(comment.text).font(.subheadline)
                            Text(Formatters.relativeDate(comment.createdAt)).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .padding()
        }
        .safeAreaInset(edge: .bottom) {
            HStack {
                TextField("Add a comment…", text: $commentText)
                    .textFieldStyle(.roundedBorder)
                Button("Post") {
                    guard !commentText.trimmingCharacters(in: .whitespaces).isEmpty else { return }
                    viewModel.addComment(to: idea, text: commentText)
                    comments.append(IdeaComment(id: UUID(), ideaId: idea.id, author: viewModel.currentUser, text: commentText, createdAt: Date()))
                    commentText = ""
                }
                .fontWeight(.semibold)
            }
            .padding()
            .background(.bar)
        }
        .navigationTitle(idea.symbol)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { comments = viewModel.comments(for: idea) }
    }
}
