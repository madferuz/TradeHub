import SwiftUI

struct FeedView: View {
    @StateObject private var viewModel = CommunityViewModel()
    @State private var showComposer = false

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 14) {
                    ForEach(viewModel.ideas) { idea in
                        NavigationLink(value: idea) {
                            IdeaCardView(idea: idea, onLike: { viewModel.toggleLike(idea) })
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding()
            }
            .navigationTitle("Community")
            .navigationDestination(for: TradeIdea.self) { idea in
                IdeaDetailView(idea: idea, viewModel: viewModel)
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showComposer = true } label: { Image(systemName: "square.and.pencil") }
                }
            }
            .sheet(isPresented: $showComposer) {
                IdeaComposerView(viewModel: viewModel)
            }
        }
    }
}

struct IdeaCardView: View {
    let idea: TradeIdea
    let onLike: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                AvatarView(systemName: idea.author.avatarSystemName, size: 36)
                VStack(alignment: .leading, spacing: 1) {
                    Text(idea.author.displayName).font(.subheadline.weight(.semibold))
                    Text("@\(idea.author.username) · \(Formatters.relativeDate(idea.createdAt))")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Spacer()
                directionBadge
            }
            Text(idea.title).font(.headline)
            Text(idea.body).font(.subheadline).foregroundStyle(.secondary).lineLimit(3)
            HStack(spacing: 20) {
                Button(action: onLike) {
                    Label("\(idea.likeCount)", systemImage: idea.isLikedByMe ? "heart.fill" : "heart")
                        .foregroundStyle(idea.isLikedByMe ? Theme.bearish : .secondary)
                }
                .buttonStyle(.plain)
                Label("\(idea.commentCount)", systemImage: "bubble.right")
                    .foregroundStyle(.secondary)
                Spacer()
                Text(idea.symbol).font(.caption.weight(.semibold)).foregroundStyle(Theme.accent)
            }
            .font(.caption)
        }
        .cardStyle()
    }

    private var directionBadge: some View {
        Text(idea.direction.rawValue.uppercased())
            .font(.caption2.weight(.bold))
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(idea.direction == .long ? Theme.bullish.opacity(0.15) : Theme.bearish.opacity(0.15))
            .foregroundStyle(idea.direction == .long ? Theme.bullish : Theme.bearish)
            .clipShape(Capsule())
    }
}

extension TradeIdea: Hashable {
    static func == (lhs: TradeIdea, rhs: TradeIdea) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}
