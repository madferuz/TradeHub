import SwiftUI

struct IdeaComposerView: View {
    @ObservedObject var viewModel: CommunityViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var symbol = "EURUSD"
    @State private var direction: IdeaDirection = .long
    @State private var title = ""
    @State private var body_ = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Symbol") {
                    Picker("Symbol", selection: $symbol) {
                        ForEach(MockDataGenerator.symbols) { instrument in
                            Text(instrument.symbol).tag(instrument.symbol)
                        }
                    }
                }
                Section("Direction") {
                    Picker("Direction", selection: $direction) {
                        Text("Long").tag(IdeaDirection.long)
                        Text("Short").tag(IdeaDirection.short)
                    }
                    .pickerStyle(.segmented)
                }
                Section("Title") {
                    TextField("Give your idea a headline", text: $title)
                }
                Section("Analysis") {
                    TextEditor(text: $body_).frame(minHeight: 140)
                }
            }
            .navigationTitle("New Idea")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Publish") {
                        viewModel.publishIdea(symbol: symbol, direction: direction, title: title.isEmpty ? "\(symbol) \(direction.rawValue) idea" : title, body: body_)
                        dismiss()
                    }
                }
            }
        }
    }
}
