import SwiftUI

struct BrokersView: View {
    @StateObject private var viewModel = BrokersViewModel()
    @State private var brokerToConnect: Broker?

    var body: some View {
        List {
            Section("Connected Accounts") {
                if viewModel.connectedAccounts.isEmpty {
                    Text("No accounts connected yet.").foregroundStyle(.secondary)
                } else {
                    ForEach(viewModel.connectedAccounts) { account in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(account.brokerName).font(.subheadline.weight(.semibold))
                                Text("\(account.accountNumber) · \(account.currency)").font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(Formatters.currency(account.balance)).font(.subheadline)
                        }
                        .swipeActions {
                            Button("Disconnect", role: .destructive) { viewModel.disconnect(account) }
                        }
                    }
                }
            }
            Section("Available Brokers") {
                ForEach(viewModel.availableBrokers) { broker in
                    Button {
                        brokerToConnect = broker
                    } label: {
                        HStack {
                            Image(systemName: broker.logoSystemName).frame(width: 28).foregroundStyle(Theme.accent)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(broker.name).font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                                Text(supportLabel(broker)).font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle("Brokers")
        .sheet(item: $brokerToConnect) { broker in
            ConnectBrokerView(viewModel: viewModel, broker: broker)
        }
    }

    private func supportLabel(_ broker: Broker) -> String {
        var items: [String] = []
        if broker.supportsForex { items.append("Forex") }
        if broker.supportsCrypto { items.append("Crypto") }
        if broker.supportsStocks { items.append("Stocks") }
        return items.joined(separator: " · ")
    }
}
