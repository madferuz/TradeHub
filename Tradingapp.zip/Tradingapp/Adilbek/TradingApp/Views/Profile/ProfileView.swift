import SwiftUI

struct ProfileView: View {
    private let user = MockCommunityService.shared.currentUser()

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 14) {
                        AvatarView(systemName: user.avatarSystemName, size: 56)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(user.displayName).font(.headline)
                            Text("@\(user.username)").font(.caption).foregroundStyle(.secondary)
                            Text(user.bio).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    HStack {
                        stat("Followers", "\(user.followers)")
                        stat("Following", "\(user.following)")
                        stat("Win Rate", Formatters.percent(user.winRate * 100).replacingOccurrences(of: "+", with: ""))
                    }
                }
                Section("Trading") {
                    NavigationLink("Connected Brokers") { BrokersView() }
                    NavigationLink("Trade History") { PortfolioView() }
                }
                Section("Account") {
                    Label("Security & Login", systemImage: "lock")
                    Label("Notifications", systemImage: "bell")
                    Label("Payment Methods", systemImage: "creditcard")
                    Label("Help & Support", systemImage: "questionmark.circle")
                }
                Section {
                    Button("Log Out", role: .destructive) {}
                }
            }
            .navigationTitle("Profile")
        }
    }

    private func stat(_ title: String, _ value: String) -> some View {
        VStack {
            Text(value).font(.subheadline.weight(.bold))
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}
