import SwiftUI

struct ConnectBrokerView: View {
    @ObservedObject var viewModel: BrokersViewModel
    let broker: Broker
    @Environment(\.dismiss) private var dismiss

    @State private var login = ""
    @State private var password = ""
    @State private var server = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("\(broker.name) Login") {
                    TextField("Account / Login", text: $login)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                    SecureField("Password", text: $password)
                    TextField("Server (optional)", text: $server)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                }
                Section {
                    Text("Demo connection — no real broker credentials are transmitted. In production this would call the broker's official trading API.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Connect Broker")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(viewModel.isConnecting ? "Connecting…" : "Connect") {
                        viewModel.connect(broker: broker, login: login.isEmpty ? "DEMO-\(Int.random(in: 10000...99999))" : login, password: password, server: server) {
                            dismiss()
                        }
                    }
                    .disabled(viewModel.isConnecting)
                }
            }
        }
    }
}
