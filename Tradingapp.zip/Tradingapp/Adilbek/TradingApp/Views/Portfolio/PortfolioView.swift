import SwiftUI

struct PortfolioView: View {
    @StateObject private var viewModel = PortfolioViewModel()
    @State private var segment = 0

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    summaryCard
                    Picker("View", selection: $segment) {
                        Text("Calendar").tag(0)
                        Text("History").tag(1)
                    }
                    .pickerStyle(.segmented)

                    if segment == 0 {
                        PnLCalendarView(dailyPnL: viewModel.dailyPnL())
                    } else {
                        TradeHistoryView(viewModel: viewModel)
                    }
                }
                .padding()
            }
            .navigationTitle("Portfolio")
        }
    }

    private var summaryCard: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Total P&L").font(.caption).foregroundStyle(.secondary)
                PnLBadge(value: viewModel.totalProfit)
                    .font(.title3.bold())
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 4) {
                Text("Win Rate").font(.caption).foregroundStyle(.secondary)
                Text(Formatters.percent(viewModel.winRate * 100).replacingOccurrences(of: "+", with: ""))
                    .font(.title3.bold())
            }
        }
        .cardStyle()
    }
}
