import SwiftUI

struct PnLCalendarView: View {
    let dailyPnL: [Date: Double]
    @State private var displayedMonth: Date = Date()
    @State private var selectedDay: Date? = nil

    private let calendar = Calendar.current

    var body: some View {
        VStack(spacing: 12) {
            monthHeader
            weekdayHeader
            calendarGrid
            if let selectedDay, let value = dailyPnL[calendar.startOfDay(for: selectedDay)] {
                HStack {
                    Text(Formatters.shortDate(selectedDay)).font(.subheadline.weight(.semibold))
                    Spacer()
                    PnLBadge(value: value)
                }
                .padding(.top, 4)
            }
        }
        .cardStyle()
    }

    private var monthHeader: some View {
        HStack {
            Button { changeMonth(by: -1) } label: { Image(systemName: "chevron.left") }
            Spacer()
            Text(monthTitle).font(.headline)
            Spacer()
            Button { changeMonth(by: 1) } label: { Image(systemName: "chevron.right") }
        }
    }

    private var weekdayHeader: some View {
        HStack {
            ForEach(["S", "M", "T", "W", "T", "F", "S"], id: \.self) { day in
                Text(day).font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity)
            }
        }
    }

    private var calendarGrid: some View {
        let days = daysInMonthGrid()
        return LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 6) {
            ForEach(days, id: \.self) { day in
                if let day {
                    dayCell(day)
                } else {
                    Color.clear.frame(height: 40)
                }
            }
        }
    }

    private func dayCell(_ day: Date) -> some View {
        let key = calendar.startOfDay(for: day)
        let pnl = dailyPnL[key]
        let bg: Color = {
            guard let pnl else { return Color.clear }
            return pnl >= 0 ? Theme.bullish.opacity(0.22) : Theme.bearish.opacity(0.22)
        }()
        return VStack(spacing: 2) {
            Text("\(calendar.component(.day, from: day))")
                .font(.caption2.weight(.medium))
            if let pnl {
                Text(shortAmount(pnl))
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(Theme.pnlColor(pnl))
            }
        }
        .frame(height: 40)
        .frame(maxWidth: .infinity)
        .background(bg)
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .onTapGesture { selectedDay = day }
    }

    private func shortAmount(_ value: Double) -> String {
        let sign = value >= 0 ? "+" : "-"
        return "\(sign)\(Int(abs(value)))"
    }

    private var monthTitle: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: displayedMonth)
    }

    private func changeMonth(by value: Int) {
        if let newMonth = calendar.date(byAdding: .month, value: value, to: displayedMonth) {
            displayedMonth = newMonth
        }
    }

    private func daysInMonthGrid() -> [Date?] {
        guard let range = calendar.range(of: .day, in: .month, for: displayedMonth),
              let firstOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: displayedMonth)) else {
            return []
        }
        let firstWeekday = calendar.component(.weekday, from: firstOfMonth) - 1
        var days: [Date?] = Array(repeating: nil, count: firstWeekday)
        for dayOffset in 0..<range.count {
            if let date = calendar.date(byAdding: .day, value: dayOffset, to: firstOfMonth) {
                days.append(date)
            }
        }
        return days
    }
}
