import SwiftUI

struct TradeHistoryView: View {
    @ObservedObject var viewModel: PortfolioViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                filterChip(title: "All", isOn: viewModel.selectedFilter == nil) { viewModel.selectedFilter = nil }
                filterChip(title: "Buys", isOn: viewModel.selectedFilter == .buy) { viewModel.selectedFilter = .buy }
                filterChip(title: "Sells", isOn: viewModel.selectedFilter == .sell) { viewModel.selectedFilter = .sell }
            }
            ForEach(viewModel.filteredTrades.prefix(40)) { trade in
                TradeRow(trade: trade)
                Divider()
            }
        }
    }

    private func filterChip(title: String, isOn: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.caption.weight(.medium))
                .padding(.horizontal, 12).padding(.vertical, 6)
                .background(isOn ? Theme.accent.opacity(0.18) : Theme.cardBg)
                .foregroundStyle(isOn ? Theme.accent : .secondary)
                .clipShape(Capsule())
        }
    }
}

private struct TradeRow: View {
    let trade: Trade

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(trade.symbol).font(.subheadline.weight(.semibold))
                    Text(trade.side.rawValue)
                        .font(.caption2.weight(.bold))
                        .padding(.horizontal, 6).padding(.vertical, 2)
                        .background(trade.side == .buy ? Theme.bullish.opacity(0.15) : Theme.bearish.opacity(0.15))
                        .foregroundStyle(trade.side == .buy ? Theme.bullish : Theme.bearish)
                        .clipShape(Capsule())
                }
                Text("\(trade.brokerName) · \(Formatters.shortDate(trade.closedAt))")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
            PnLBadge(value: trade.profit)
        }
        .padding(.vertical, 4)
    }
}
