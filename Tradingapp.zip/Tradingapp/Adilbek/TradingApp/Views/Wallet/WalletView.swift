import SwiftUI

struct WalletView: View {
    @StateObject private var viewModel = WalletViewModel()
    @State private var showDeposit = false
    @State private var showWithdraw = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    balanceCard
                    actionButtons
                    accountsSection
                    transactionsSection
                }
                .padding()
            }
            .navigationTitle("Wallet")
            .sheet(isPresented: $showDeposit) {
                DepositView(viewModel: viewModel)
            }
            .sheet(isPresented: $showWithdraw) {
                WithdrawView(viewModel: viewModel)
            }
        }
    }

    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Total Balance").font(.caption).foregroundStyle(.secondary)
            Text(Formatters.currency(viewModel.totalBalance)).font(.largeTitle.bold())
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    private var actionButtons: some View {
        HStack(spacing: 12) {
            Button { showDeposit = true } label: {
                Label("Deposit", systemImage: "arrow.down.circle.fill")
                    .frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(Theme.bullish.opacity(0.15))
                    .foregroundStyle(Theme.bullish)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Button { showWithdraw = true } label: {
                Label("Withdraw", systemImage: "arrow.up.circle.fill")
                    .frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(Theme.accent.opacity(0.15))
                    .foregroundStyle(Theme.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
    }

    private var accountsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(title: "Broker Accounts")
            ForEach(viewModel.accounts) { account in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(account.brokerName).font(.subheadline.weight(.semibold))
                        Text(account.accountNumber).font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(Formatters.currency(account.balance)).font(.subheadline.weight(.medium))
                        Text("Equity \(Formatters.currency(account.equity))").font(.caption2).foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 4)
                Divider()
            }
        }
        .cardStyle()
    }

    private var transactionsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(title: "Recent Transactions")
            ForEach(viewModel.transactions) { tx in
                TransactionRow(transaction: tx)
                Divider()
            }
        }
        .cardStyle()
    }
}

private struct TransactionRow: View {
    let transaction: WalletTransaction

    var body: some View {
        HStack {
            Image(systemName: transaction.method.systemImage)
                .foregroundStyle(Theme.accent)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(transaction.type.rawValue).font(.subheadline.weight(.semibold))
                Text("\(transaction.brokerAccountLabel)").font(.caption2).foregroundStyle(.secondary)
                Text(Formatters.relativeDate(transaction.date)).font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(transaction.type == .deposit ? "+\(Formatters.currency(transaction.amount))" : "-\(Formatters.currency(transaction.amount))")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(transaction.type == .deposit ? Theme.bullish : .primary)
                statusBadge
            }
        }
        .padding(.vertical, 4)
    }

    private var statusBadge: some View {
        let color: Color = transaction.status == .completed ? Theme.bullish : (transaction.status == .pending ? .orange : Theme.bearish)
        return Text(transaction.status.rawValue)
            .font(.caption2.weight(.medium))
            .padding(.horizontal, 6).padding(.vertical, 2)
            .background(color.opacity(0.15))
            .foregroundStyle(color)
            .clipShape(Capsule())
    }
}
