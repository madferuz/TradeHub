import SwiftUI

struct DepositView: View {
    @ObservedObject var viewModel: WalletViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var selectedAccount: BrokerAccount?
    @State private var amountText = "500"
    @State private var method: PaymentMethod = .card

    var body: some View {
        NavigationStack {
            Form {
                Section("To Account") {
                    Picker("Account", selection: $selectedAccount) {
                        ForEach(viewModel.accounts) { account in
                            Text("\(account.brokerName) · \(account.accountNumber)").tag(Optional(account))
                        }
                    }
                }
                Section("Amount (USD)") {
                    TextField("Amount", text: $amountText).keyboardType(.decimalPad)
                }
                Section("Payment Method") {
                    Picker("Method", selection: $method) {
                        ForEach(PaymentMethod.allCases) { m in Text(m.rawValue).tag(m) }
                    }
                    .pickerStyle(.inline)
                }
                Section {
                    Text("This is a demo deposit flow using mock data — no real payment is processed.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Deposit")
            .onAppear { selectedAccount = viewModel.accounts.first }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Deposit") {
                        if let account = selectedAccount, let amount = Double(amountText), amount > 0 {
                            viewModel.deposit(amount: amount, method: method, into: account)
                        }
                        dismiss()
                    }
                }
            }
        }
    }
}
