import SwiftUI

struct WithdrawView: View {
    @ObservedObject var viewModel: WalletViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var selectedAccount: BrokerAccount?
    @State private var amountText = "200"
    @State private var method: PaymentMethod = .bankTransfer

    var body: some View {
        NavigationStack {
            Form {
                Section("From Account") {
                    Picker("Account", selection: $selectedAccount) {
                        ForEach(viewModel.accounts) { account in
                            Text("\(account.brokerName) · \(account.accountNumber)").tag(Optional(account))
                        }
                    }
                    if let selectedAccount {
                        Text("Available: \(Formatters.currency(selectedAccount.balance))").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("Amount (USD)") {
                    TextField("Amount", text: $amountText).keyboardType(.decimalPad)
                }
                Section("Payout Method") {
                    Picker("Method", selection: $method) {
                        ForEach(PaymentMethod.allCases) { m in Text(m.rawValue).tag(m) }
                    }
                    .pickerStyle(.inline)
                }
                Section {
                    Text("This is a demo withdrawal flow using mock data — no real funds move.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Withdraw")
            .onAppear { selectedAccount = viewModel.accounts.first }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Withdraw") {
                        if let account = selectedAccount, let amount = Double(amountText), amount > 0, amount <= account.balance {
                            viewModel.withdraw(amount: amount, method: method, from: account)
                        }
                        dismiss()
                    }
                }
            }
        }
    }
}
