import SwiftUI

struct RootTabView: View {
    var body: some View {
        TabView {
            TerminalView()
                .tabItem { Label("Terminal", systemImage: "chart.xyaxis.line") }

            PortfolioView()
                .tabItem { Label("Portfolio", systemImage: "calendar") }

            WalletView()
                .tabItem { Label("Wallet", systemImage: "wallet.pass") }

            FeedView()
                .tabItem { Label("Community", systemImage: "person.3") }

            ConversationsView()
                .tabItem { Label("Messages", systemImage: "bubble.left.and.bubble.right") }

            ProfileView()
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
        }
        .tint(Theme.accent)
    }
}

#Preview {
    RootTabView()
}
