import SwiftUI

struct ConversationsView: View {
    @StateObject private var viewModel = MessagingViewModel()

    var body: some View {
        NavigationStack {
            List(viewModel.conversations) { conversation in
                NavigationLink(value: conversation) {
                    HStack(spacing: 12) {
                        AvatarView(systemName: conversation.participant.avatarSystemName, size: 44)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(conversation.participant.displayName).font(.subheadline.weight(.semibold))
                            Text(conversation.lastMessagePreview).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            Text(Formatters.relativeDate(conversation.lastMessageDate)).font(.caption2).foregroundStyle(.secondary)
                            if conversation.unreadCount > 0 {
                                Text("\(conversation.unreadCount)")
                                    .font(.caption2.weight(.bold))
                                    .padding(6)
                                    .background(Theme.accent)
                                    .foregroundStyle(.white)
                                    .clipShape(Circle())
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Messages")
            .navigationDestination(for: Conversation.self) { conversation in
                ChatView(viewModel: viewModel, conversation: conversation)
            }
        }
    }
}

extension Conversation: Hashable {
    static func == (lhs: Conversation, rhs: Conversation) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}
