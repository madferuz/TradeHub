import SwiftUI

struct ChatView: View {
    @ObservedObject var viewModel: MessagingViewModel
    let conversation: Conversation
    @State private var draft = ""

    private var current: Conversation {
        viewModel.conversations.first(where: { $0.id == conversation.id }) ?? conversation
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 10) {
                    ForEach(current.messages) { message in
                        bubble(message)
                            .id(message.id)
                    }
                }
                .padding()
            }
            .onChange(of: current.messages.count) { _, _ in
                if let last = current.messages.last {
                    withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
        }
        .safeAreaInset(edge: .bottom) {
            HStack {
                TextField("Message…", text: $draft)
                    .textFieldStyle(.roundedBorder)
                Button {
                    guard !draft.trimmingCharacters(in: .whitespaces).isEmpty else { return }
                    viewModel.send(text: draft, in: conversation)
                    draft = ""
                } label: {
                    Image(systemName: "arrow.up.circle.fill").font(.title2)
                }
            }
            .padding()
            .background(.bar)
        }
        .navigationTitle(conversation.participant.displayName)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func bubble(_ message: ChatMessage) -> some View {
        HStack {
            if message.isMe { Spacer(minLength: 40) }
            Text(message.text)
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(message.isMe ? Theme.accent : Theme.cardBg)
                .foregroundStyle(message.isMe ? .white : .primary)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            if !message.isMe { Spacer(minLength: 40) }
        }
        .frame(maxWidth: .infinity, alignment: message.isMe ? .trailing : .leading)
    }
}
